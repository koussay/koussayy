#include <gtk/gtk.h>


void
on_buttonretourex_clicked              (GtkWidget *objet,
                                        gpointer         user_data);

void
on_buttonajouterex_clicked             (GtkWidget *objet,
                                        gpointer         user_data);

void
on_buttonconsulter_clicked             (GtkWidget *objet,
                                        gpointer         user_data);

void
on_buttonretourajouterex_clicked       (GtkWidget *objet,
                                        gpointer         user_data);

void
on_buttonajouterex2_clicked            (GtkWidget *objet,
                                        gpointer         user_data);

void
on_buttonretourconsulterex_clicked     (GtkWidget *objet,
                                        gpointer         user_data);

void
on_treeviewex_row_activated            (GtkWidget *objet,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonmodif_clicked                 (GtkWidget *objet,
                                        gpointer         user_data);

void
on_buttonsupp_clicked                  (GtkWidget *objet,
                                        gpointer         user_data);

void
on_buttonretourmodifex_clicked         (GtkWidget *objet,
                                        gpointer         user_data);

void
on_buttonreserverex_clicked            (GtkWidget *objet,
                                        gpointer         user_data);

void
on_buttonpanierex_clicked              (GtkWidget *objet,
                                        gpointer         user_data);

void
on_buttonretourex1_clicked             (GtkWidget *objet,
                                        gpointer         user_data);

void
on_buttonretourclientex_clicked        (GtkWidget *objet,
                                        gpointer         user_data);
