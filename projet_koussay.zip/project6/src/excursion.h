#include <gtk/gtk.h> 

typedef struct 
{ 
char destination[30] ; 
char date [30] ; 
char heure[30] ;
char nb_nuit[30] ; 
char prix[30] ;
} excursion; 

void ajouter_excursion(excursion h); 
void modifier_excursion(excursion h); 
void supprimer_excursion(excursion h); 
void afficher_excursion(GtkWidget *liste); 
int verifier_ajouter(excursion h) ;
typedef struct
{
excursion a;
char nb_personne[30];
;
}reservation_excursion;
int verifier1(char destination[30],char date[30],char nb_nuit[30],char prix[30]);
void ajouter_excursion1(reservation_excursion h );
void afficher_excursion1(GtkWidget *liste);
