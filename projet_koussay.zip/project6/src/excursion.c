#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>
#include "excursion.h"

int verifier_ajouter(excursion h)
{
	if(strcmp(h.destination,"")==0 || strcmp(h.date,"")==0|| strcmp(h.heure,"")==0|| strcmp(h.nb_nuit,"")==0|| strcmp(h.prix,"")==0) return (0);
else return (1);
}
void ajouter_excursion(excursion h)
{
FILE* f;
f=fopen("excursion.txt","a");
  if(f!=NULL)
   {
   fprintf(f,"%s %s %s %s %s \n",h.destination,h.date,h.heure,h.nb_nuit,h.prix);
   }
fclose(f);
}

void afficher_excursion(GtkWidget *liste)
{
enum
{   DESTINATION,
    DATE,
    HEURE,
    NB_NUIT,
    PRIX,
    COLUMNS
};
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char destination[30] ; 
char date [30] ; 
char heure [30] ;
char nb_nuit[30] ; 
char prix[30] ;
store=NULL;

FILE  *f;

store=gtk_tree_view_get_model(liste);

  if(store==NULL)
  {
   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("destination",renderer,"text",DESTINATION,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",DATE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("heure",renderer,"text",HEURE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("nb_nuit",renderer,"text",NB_NUIT,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",PRIX,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   
   store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("excursion.txt","r");

     if(f!=NULL)
        {
         while(fscanf(f,"%s %s %s %s %s\n",destination,date,heure,nb_nuit,prix)!=EOF)
          {
           gtk_list_store_append(store,&iter);
     gtk_list_store_set(store,&iter,DESTINATION,destination,DATE,date,HEURE,heure,NB_NUIT,nb_nuit,PRIX,prix,-1);
          }
        }
   fclose(f);
   gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
   g_object_unref(store);  
   }
}

void supprimer_excursion (excursion x)
{
	excursion h;
FILE *f;
FILE *g;
f=fopen("excursion.txt","r");
g=fopen("excursion2.txt","a+");
while (fscanf(f,"%s %s %s %s %s \n",h.destination,h.date,h.heure,h.nb_nuit,h.prix)!=EOF)
{
if(strcmp(x.destination,h.destination)!=0) 
fprintf(g,"%s %s %s %s %s \n",h.destination,h.date,h.heure,h.nb_nuit,h.prix);
}
fclose(f);
fclose(g);
remove("excursion.txt");
rename("excursion2.txt","excursion.txt");
}

void modifier_excursion(excursion h1)
{
excursion v;
FILE *f;
FILE *aux;
aux=NULL;
f=fopen("excursion.txt","r+");
aux=fopen("excursion2.txt","a+");
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s  \n",v.destination,v.date,v.heure,v.nb_nuit,v.prix)!=EOF)
 {
	if(strcmp(h1.destination,v.destination)==0) v=h1;
                fprintf(aux,"%s %s %s %s %s  \n",v.destination,v.date,v.heure,v.nb_nuit,v.prix);
}
 fclose(aux);
    fclose(f);
	remove("excursion.txt");
      rename("excursion2.txt","excursion.txt");
}
}


void ajouter_excursion1(reservation_excursion h )
{
FILE* f;

f=fopen("excursion_reserve.txt","a");
     
  if(f!=NULL)
   {
   fprintf(f,"%s %s %s %s %s \n",h.a.destination,h.a.date,h.a.nb_nuit,h.a.prix,h.nb_personne);
   }

fclose(f);
}
void afficher_excursion1(GtkWidget *liste)
{
enum
{

  DESTINATION1,
  DATE1,
  NB_NUIT1,
  PRIX1,
  NB_PERSONNE,
  COLUMNS1
};
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char destination[30];
char date[30];
char nb_nuit[30];
char prix[30];
char nb_personne[30];
store=NULL;

FILE  *f;

store=gtk_tree_view_get_model(liste);

  if(store==NULL)
  {


   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("destination",renderer,"text",DESTINATION1,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);	


   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",DATE1,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("nb_nuit",renderer,"text",NB_NUIT1,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",PRIX1,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer=gtk_cell_renderer_text_new();
   column=gtk_tree_view_column_new_with_attributes("nb_personne",renderer,"text",NB_PERSONNE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

  store=gtk_list_store_new(COLUMNS1,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

   f=fopen("excursion_reserve.txt","r");

     if(f!=NULL)
        {
         f=fopen("excursion_reserve.txt","a+");
         while(fscanf(f,"%s %s %s %s %s ",destination,date,nb_nuit,prix,nb_personne)!=EOF)
          {
           gtk_list_store_append(store,&iter);
           gtk_list_store_set(store,&iter,DESTINATION1,destination,DATE1,date,NB_NUIT1,nb_nuit,PRIX1,prix,NB_PERSONNE,nb_personne,-1);
          }
        }
   fclose(f);


   gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
   g_object_unref(store);  
   }
}


int verifier1(char destination [30],char date[30],char nb_nuit[30],char prix[30])
{
int v=0;
reservation_excursion h;
FILE* f=fopen("excursion.txt","r");
 if(f!=NULL)
  {
   while(v!=1 && fscanf(f,"%s %s %s %s %s",h.a.destination,h.a.date,h.a.heure,h.a.nb_nuit,h.a.prix)!=EOF)
     {
       if(strcmp(destination,h.a.destination)==0 && strcmp(date,h.a.date)==0 && strcmp(nb_nuit,h.a.nb_nuit)==0 && strcmp(prix,h.a.prix)==0)

               {
                v=1;
               }
      }
   }
return(v);
fclose(f);
}
