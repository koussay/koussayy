#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "excursion.h"


void
on_buttonretourex_clicked              (GtkWidget *objet,
                                        gpointer         user_data)
{

}


void
on_buttonajouterex_clicked             (GtkWidget *objet,
                                        gpointer         user_data)
{GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet,"excursionagent");
gtk_widget_destroy(window1);
window2=create_windowajouterex();
gtk_widget_show(window2);

}


void
on_buttonconsulter_clicked             (GtkWidget *objet,
                                        gpointer         user_data)
{GtkWidget *window1;
GtkWidget *window2;
GtkWidget *treeview1;
window1=lookup_widget(objet,"excursionagent");
gtk_widget_destroy(window1);
window2=create_windowconsulterex();
gtk_widget_show(window2);
treeview1=lookup_widget(window2,"treeviewex");
afficher_excursion(treeview1);

}


void
on_buttonretourajouterex_clicked       (GtkWidget *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet,"windowajouterex");
gtk_widget_destroy(window1);
window2=create_excursionagent();
gtk_widget_show(window2);
}


void
on_buttonajouterex2_clicked            (GtkWidget *objet,
                                        gpointer         user_data)
{
excursion h;
GtkWidget *input1,*input2,*input3,*input4,*input5,*output1;
char confirmation[30];


input1=lookup_widget(objet,"comboboxdestination1");
input2=lookup_widget(objet,"entrydate");
input3=lookup_widget(objet,"entryheure");
input4=lookup_widget(objet,"comboboxnb_nuit1");
input5=lookup_widget(objet,"comboboxprix1");
output1=lookup_widget(objet,"labelconfirmationex");

strcpy(h.destination,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
strcpy(h.date,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(h.heure,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h.nb_nuit,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));
strcpy(h.prix,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));
if (verifier_ajouter(h)==1)
{	GdkColor color;
	gdk_color_parse ("green", &color);
	gtk_widget_modify_fg (output1, GTK_STATE_NORMAL, &color);
	gtk_label_set_text(GTK_LABEL (output1), confirmation);
	strcpy(confirmation,"excursion ajouté");
	gtk_label_set_text(GTK_LABEL(output1),confirmation);

ajouter_excursion(h);}
}


void
on_buttonretourconsulterex_clicked     (GtkWidget *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet,"windowconsulterex");
gtk_widget_destroy(window1);
window2=create_excursionagent();
gtk_widget_show(window2);
}


void
on_treeviewex_row_activated            (GtkWidget *objet,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *destination,*date,*heure,*nb_nuit,*prix;
	GtkWidget *window1;
	GtkWidget *window2;
	GtkWidget *treeview;
	GtkWidget *destination1,*date1,*heure1,*nb_nuit1,*prix1;
	window1=lookup_widget(objet,"windowconsulterex");
	treeview=lookup_widget(objet,"treeviewex");
	window2=create_windowmodifierex();
	destination1=lookup_widget(window2,"destination");
	date1=lookup_widget(window2,"date");
	heure1=lookup_widget(window2,"heure");
	nb_nuit1=lookup_widget(window2,"nb_nuit");
	prix1=lookup_widget(window2,"prix");
	
	GtkTreeIter iter;
	GtkTreeModel *model=gtk_tree_view_get_model (GTK_TREE_VIEW(treeview));
	gtk_tree_model_get_iter(model,&iter,path);
	gtk_tree_model_get (model,&iter,0,&destination,1,&date,2,&heure,3,&nb_nuit,4,&prix,-1);
	printf("%s %s %s %s  %s\n",destination,date,heure,nb_nuit,prix);
	gtk_entry_set_text(GTK_ENTRY (destination1),(destination));
	gtk_entry_set_text(GTK_ENTRY (date1),(date));
	gtk_entry_set_text(GTK_ENTRY (heure1),(heure));
	gtk_entry_set_text(GTK_ENTRY (nb_nuit1),(nb_nuit));
	gtk_entry_set_text(GTK_ENTRY (prix1),(prix));
	
        gtk_widget_destroy(window1);
	gtk_widget_show(window2);

}


void
on_buttonmodif_clicked                 (GtkWidget *objet,
                                        gpointer         user_data)

{
    excursion h;
	GtkWidget *input1;
	GtkWidget *input2;
	GtkWidget *input3;
	GtkWidget *input4;
	GtkWidget *input5;
	GtkWidget *output1;
	char succes[30];
	input1=lookup_widget(objet,"destination");
	input2=lookup_widget(objet,"date");
	input3=lookup_widget(objet,"heure");
	input4=lookup_widget(objet,"nb_nuit");
        input5=lookup_widget(objet,"prix");
	
	
	output1=lookup_widget(objet,"confirmationex");
	strcpy(h.destination,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(h.date,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(h.heure,gtk_entry_get_text(GTK_ENTRY(input3)));
	strcpy(h.nb_nuit,gtk_entry_get_text(GTK_ENTRY(input4)));
	strcpy(h.prix,gtk_entry_get_text(GTK_ENTRY(input5)));
	
	strcpy(succes,"Modification avec succés");
        GdkColor color;
	gdk_color_parse ("green", &color);
	gtk_widget_modify_fg (output1, GTK_STATE_NORMAL, &color);
	gtk_label_set_text(GTK_LABEL (output1), succes);
	modifier_excursion(h); 
}


void
on_buttonsupp_clicked                  (GtkWidget *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
	GtkWidget *window2;
	char confirmation[50];
	excursion h;
	window1=lookup_widget(objet,"windowmodifierex");
	GtkWidget *input1;
	GtkWidget *output1;
	input1=lookup_widget(objet,"destination");
	output1=lookup_widget(objet,"confirmationex");
	strcpy(h.destination,gtk_entry_get_text(GTK_ENTRY(input1)));
	supprimer_excursion(h);
	GdkColor color;
	gdk_color_parse ("red", &color);
	gtk_widget_modify_fg (output1, GTK_STATE_NORMAL, &color);
	gtk_label_set_text(GTK_LABEL (output1), confirmation);
	strcpy(confirmation,"Suppression avec succes");
	gtk_label_set_text(GTK_LABEL(output1),confirmation);

}


void
on_buttonretourmodifex_clicked         (GtkWidget *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *treeview1;
window1=lookup_widget(objet,"windowmodifierex");
gtk_widget_destroy(window1);
window2=create_windowconsulterex();
gtk_widget_show(window2);
treeview1=lookup_widget(window2,"treeviewex");
afficher_excursion(treeview1);
}




void
on_buttonreserverex_clicked            (GtkWidget *objet,
                                        gpointer         user_data)
{
GtkWidget *Destination;
GtkWidget *Prix;
GtkWidget *Nb_nuit;
GtkWidget *Date;
GtkWidget *Nb_personne;
GtkWidget *sortie;

char destination[30];
char prix[30];
char nb_nuit[30];
char date[30];
char nb_personne[30];
reservation_excursion h;

Destination=lookup_widget(objet,"comboboxdestination");
Prix=lookup_widget(objet,"comboboxprix");
Nb_nuit=lookup_widget(objet,"comboboxnb_nuit");
Date=lookup_widget(objet,"entrydate1");
Nb_personne=lookup_widget(objet,"entrynb_personne");
sortie=lookup_widget(objet,"labelconfirmation1");
strcpy(h.a.destination,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Destination)));
strcpy(h.a.prix,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Prix)));
strcpy(h.a.nb_nuit,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Nb_nuit)));
strcpy(h.a.date,gtk_entry_get_text(GTK_ENTRY(Date)));
strcpy(h.nb_personne,gtk_entry_get_text(GTK_ENTRY(Nb_personne)));
if (verifier1(h.a.destination,h.a.date,h.a.nb_nuit,h.a.prix))
{
ajouter_excursion1(h);
GdkColor color;
gdk_color_parse ("green", &color);
gtk_widget_modify_fg (sortie, GTK_STATE_NORMAL, &color);
gtk_label_set_text(GTK_LABEL(sortie),"reservation réussite");}
else 
{GdkColor color;
gdk_color_parse ("red", &color);
gtk_widget_modify_fg (sortie, GTK_STATE_NORMAL, &color);
gtk_label_set_text(GTK_LABEL(sortie),"verifier les donnees");}
}


void
on_buttonpanierex_clicked              (GtkWidget *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
GtkWidget *treeview1;
window1=lookup_widget(objet,"excursionclient");
gtk_widget_destroy(window1);
window2=create_windowpanierex();
gtk_widget_show(window2);
treeview1=lookup_widget(window2,"treeviewclientex");
afficher_excursion1(treeview1);
}


void
on_buttonretourex1_clicked             (GtkWidget *objet,
                                        gpointer         user_data)
{

}


void
on_buttonretourclientex_clicked        (GtkWidget *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *window2;
window1=lookup_widget(objet,"windowpanierex");
gtk_widget_destroy(window1);
window2=create_excursionclient();
gtk_widget_show(window2);
}

